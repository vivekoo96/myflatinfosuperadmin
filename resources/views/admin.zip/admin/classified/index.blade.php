@extends('layouts.admin')


@section('title')
    Classified List
@endsection

@section('content')
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-md-12">
                @if(session()->has('error'))
                <div class="alert alert-danger">
                    {{ session()->get('error') }}
                </div>
                @endif
                @if(session()->has('success'))
                <div class="alert alert-success">
                    {{ session()->get('success') }}
                </div>
                @endif
            </div>
          <div class="col-sm-6">
            <h1>Classified List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Classifieds</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">

            <div class="card">
              <div class="card-header">
                <button class="btn btn-sm btn-success right" data-toggle="modal" data-target="#addModal">Add New Classified</button>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>S No</th>
                    <th>Posted By</th>
                    <th>Category</th>
                    <th>Title</th>
                    <th>Desc</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    
                    <?php $i = 0; ?>
                  @forelse($classifieds as $item)
                  <?php $i++; ?>
                  <tr>
                    <td>{{$i}}</td>
                    <td><a href="{{url('customer',$item->user_id)}}">{{$item->user->name}}</a></td>
                    <td>{{$item->category}}</td>
                    <td>{{$item->title}}</td>
                    <td>{{$item->desc}}</td>
                    <td>{{$item->status}}</td>
                    <td>
                      <a href="{{route('classified.show',$item->id)}}" target="_blank"  class="btn btn-sm btn-warning"><i class="fa fa-eye"></i></a>
                      <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#addModal" data-id="{{$item->id}}" data-title="{{$item->title}}" data-desc="{{$item->desc}}"  
                       data-status="{{$item->status}}" data-reason="{{$item->reason}}" 
                      data-block_id="{{$item->block_id}}" data-flat_id="{{$item->flat_id}}" data-category="{{$item->category}}"><i class="fa fa-edit"></i></button>
                      @if($item->deleted_at)
                      <button class="btn btn-sm btn-success" data-toggle="modal" data-target="#deleteModal" data-id="{{$item->id}}" data-action="restore"><i class="fa fa-undo"></i></button>
                      @else
                      <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal" data-id="{{$item->id}}" data-action="delete"><i class="fa fa-trash"></i></button>
                      @endif
                    </td>

                  </tr>
                  @empty
                  @endforelse
                  </tbody>
                </table>
                </div>
                
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

<!-- Add Modal -->

<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Classified</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="{{route('classified.store')}}" method="post" class="add-form" enctype="multipart/form-data">
        @csrf
        <div class="modal-body">
          <div class="error"></div>
          <!--<div class="form-group">-->
          <!--  <label for="name" class="col-form-label">Category:</label>-->
          <!--  <select name="category" id="category" class="form-control" required>-->
          <!--      <option value="All Buildings">All Buildings</option>-->
          <!--  </select>-->
          <!--</div>-->
          <div class="form-group">
            <label for="name" class="col-form-label">Title:</label>
            <input type="text" name="title" id="title" class="form-control" placeholder="Title" minlength="5" maxlength="100" pattern="[A-Za-z\s]+" onkeypress="return event.charCode >= 65 && event.charCode <= 90 || event.charCode >= 97 && event.charCode <= 122 || event.charCode == 32" required>
            <small class="form-text text-muted">Minimum 5 characters, Maximum 100 characters. Alphabets only.</small>
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">Description:</label>
            <textarea name="desc" id="desc" class="form-control" minlength="10" maxlength="500" placeholder="Enter description (10-500 characters)" required></textarea>
            <small class="form-text text-muted">Minimum 10 characters, Maximum 500 characters.</small>
          </div>
          <!--<div class="form-group">-->
          <!--  <label for="name" class="col-form-label">Status:</label>-->
          <!--  <select name="status" id="status" class="form-control" required>-->
          <!--      <option value="Approved">Approved</option>-->
          <!--  </select>-->
          <!--</div>-->
          
          <!-- Hidden Reason field -->
        <div class="form-group" id="reasonBox" style="display: none;">
          <label for="reason" class="col-form-label">Reason:</label>
          <textarea name="reason" id="reason" class="form-control" rows="3"></textarea>
        </div>
        
        <div class="form-group">
            <label for="name" class="col-form-label">Photos: <small>(Max 2MB per image, JPG/PNG/JPEG only)</small></label>
            <input type="file" name="photos[]" id="photos" class="form-control" accept="image/jpeg,image/jpg,image/png" multiple>
            <small class="form-text text-muted">Image format: JPG, PNG, JPEG. Maximum size: 2MB per image.</small>
          </div>

          <input type="hidden" name="id" id="edit-id">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="save-button" disabled>Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Are you sure ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p class="text"></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal" id="delete-button">Confirm Delete</button>
      </div>
    </div>
  </div>
</div>


@section('script')


<script>
  $(document).ready(function(){
    var id = '';
    var action = '';
    var token = "{{csrf_token()}}";
    
    $('#deleteModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      id = button.data('id');
      $('#delete-id').val(id);
      action= button.data('action');
      $('#delete-button').removeClass('btn-success');
      $('#delete-button').removeClass('btn-danger');
      if(action == 'delete'){
          $('#delete-button').addClass('btn-danger');
          $('#delete-button').text('Confirm Delete');
          $('.text').text('You are going to permanently delete this item..');
      }else{
          $('#delete-button').addClass('btn-success');
          $('#delete-button').text('Confirm Restore');
          $('.text').text('You are going to restore this item..');
      }
    });

    $(document).on('click','#delete-button',function(){
      var url = "{{route('classified.destroy','')}}";
      $.ajax({
        url : url + '/' + id,
        type: "DELETE",
        data : {'_token':token,'action':action},
        success: function(data)
        {
          window.location.reload();
        }
      });
    });

    $('#addModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      var edit_id = button.data('id');
      $('#edit-id').val(button.data('id'));
      $('#category').val(button.data('category'));
      $('#title').val(button.data('title'));
      $('#desc').val(button.data('desc'));

      $('#status').val(button.data('status'));
      $('#reason').val(button.data('reason'));
      $('#image2').attr('src',button.data('image'));
      $('.modal-title').text('Add New Classified');
      
      if(edit_id){
          $('.modal-title').text('Update Classified');
          $('#photos').removeAttr('required');
          $('#photos').siblings('.form-text').text('Image format: JPG, PNG, JPEG. Maximum size: 2MB per image. (Optional - keep existing images if not selected)');
      } else {
          $('#photos').attr('required', true);
          $('#photos').siblings('.form-text').text('Image format: JPG, PNG, JPEG. Maximum size: 2MB per image.');
      }
      
      // Clear any previous validation states
      $('#photos, #title, #desc').removeClass('is-valid is-invalid');
      $('.error').html('');
      
    });

    // Comprehensive form validation
    function validateForm() {
      var isValid = true;
      var title = $('#title').val().trim();
      var desc = $('#desc').val().trim();
      var photos = $('#photos')[0].files;
      var isEditMode = $('#edit-id').val() !== '';

      // Title validation
      if (title.length < 5 || title.length > 100) {
        isValid = false;
        $('#title').addClass('is-invalid');
      } else if (!/^[A-Za-z\s]+$/.test(title)) {
        isValid = false;
        $('#title').addClass('is-invalid');
      } else {
        $('#title').removeClass('is-invalid').addClass('is-valid');
      }

      // Description validation
      if (desc.length < 10 || desc.length > 500) {
        isValid = false;
        $('#desc').addClass('is-invalid');
      } else {
        $('#desc').removeClass('is-invalid').addClass('is-valid');
      }

      // Photo validation - Skip for edit mode
      if (!isEditMode) {
        if (photos.length === 0) {
          isValid = false;
          $('#photos').addClass('is-invalid');
        } else {
          var validFiles = true;
          for (var i = 0; i < photos.length; i++) {
            var file = photos[i];
            var allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
            var maxSize = 2 * 1024 * 1024; // 2MB

            if (!allowedTypes.includes(file.type)) {
              validFiles = false;
              break;
            }
            if (file.size > maxSize) {
              validFiles = false;
              break;
            }
          }
          
          if (validFiles) {
            $('#photos').removeClass('is-invalid').addClass('is-valid');
          } else {
            isValid = false;
            $('#photos').addClass('is-invalid');
          }
        }
      } else {
        // In edit mode, only validate if files are selected
        if (photos.length > 0) {
          var validFiles = true;
          for (var i = 0; i < photos.length; i++) {
            var file = photos[i];
            var allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
            var maxSize = 2 * 1024 * 1024; // 2MB

            if (!allowedTypes.includes(file.type)) {
              validFiles = false;
              break;
            }
            if (file.size > maxSize) {
              validFiles = false;
              break;
            }
          }
          
          if (validFiles) {
            $('#photos').removeClass('is-invalid').addClass('is-valid');
          } else {
            isValid = false;
            $('#photos').addClass('is-invalid');
          }
        } else {
          // No files selected in edit mode is OK
          $('#photos').removeClass('is-invalid is-valid');
        }
      }

      // Enable/disable save button
      $('#save-button').prop('disabled', !isValid);
      return isValid;
    }

    // Real-time validation
    $('#title, #desc').on('input', validateForm);
    $('#photos').on('change', function() {
      var files = this.files;
      var errorMessage = '';
      var isEditMode = $('#edit-id').val() !== '';
      
      if (files.length === 0) {
        if (!isEditMode) {
          $('.error').html('<div class="alert alert-danger">Please select at least one image.</div>');
        } else {
          $('.error').html('');
        }
        return;
      }

      for (var i = 0; i < files.length; i++) {
        var file = files[i];
        var allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
        var maxSize = 2 * 1024 * 1024; // 2MB

        if (!allowedTypes.includes(file.type)) {
          errorMessage = 'Invalid format. Only image files are accepted (JPG, PNG, JPEG).';
          break;
        }
        if (file.size > maxSize) {
          var fileSizeMB = (file.size / (1024 * 1024)).toFixed(2);
          errorMessage = 'File size too large. Maximum 2MB allowed. Current: ' + fileSizeMB + 'MB.';
          break;
        }
      }

      if (errorMessage) {
        $('.error').html('<div class="alert alert-danger">' + errorMessage + '</div>');
        $(this).addClass('is-invalid');
        $('#save-button').prop('disabled', true);
      } else {
        $('.error').html('');
        $(this).removeClass('is-invalid').addClass('is-valid');
        validateForm();
      }
    });

    // Form submission validation
    $('.add-form').on('submit', function(e) {
      if (!validateForm()) {
        e.preventDefault();
        $('.error').html('<div class="alert alert-danger">Please fix all validation errors before submitting.</div>');
        return false;
      }
    });

    // Initialize validation on modal open
    $('#addModal').on('shown.bs.modal', function() {
      validateForm();
    });

  });
</script>

@endsection

@endsection
