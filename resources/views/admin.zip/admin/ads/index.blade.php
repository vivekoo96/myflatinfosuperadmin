@extends('layouts.admin')


@section('title')
    Ad List
@endsection

@section('content')
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-md-12">
                @if(session()->has('error'))
                <div class="alert alert-danger">
                    {{ session()->get('error') }}
                </div>
                @endif
                @if(session()->has('success'))
                <div class="alert alert-success">
                    {{ session()->get('success') }}
                </div>
                @endif
            </div>
          <div class="col-sm-6">
            <h1>Ads</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Ads</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">

            <div class="card">
              <div class="card-header">
                <button class="btn btn-sm btn-success right" data-toggle="modal" data-target="#addModal">Add New Ad</button>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>S No</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>From Time</th>
                    <th>To Time</th>
                    <th>Link</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    
                    <?php $i = 0; ?>
                  @forelse($ads as $ad)
                  <?php $i++; ?>
                  <tr>
                    <td>{{$i}}</td>
                    <td><img src="{{$ad->image}}" style="width:40px"></td>
                    <td>{{$ad->name}}</td>
                    <td>{{ $ad->from_time ?? '-' }}</td>
                    <td>{{ $ad->to_time ?? '-' }}</td>
                    <td style="word-break:break-all; white-space:pre-line; max-width:220px;">{{$ad->link}}</td>
                    <td>{{$ad->status}}</td>
                    <td>
                      <!--<a href="{{route('ads.show',$ad->id)}}" target="_blank"  class="btn btn-sm btn-warning"><i class="fa fa-eye"></i></a>-->
                      <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#addModal" data-id="{{$ad->id}}" 
                      data-name="{{$ad->name}}" data-link="{{$ad->link}}" data-status="{{$ad->status}}" data-image="{{$ad->image}}" data-from_time="{{ $ad->from_time ? \Carbon\Carbon::parse($ad->from_time)->format('H:i') : '' }}" data-to_time="{{ $ad->to_time ? \Carbon\Carbon::parse($ad->to_time)->format('H:i') : '' }}"><i class="fa fa-edit"></i></button>
                      <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal" data-id="{{$ad->id}}" data-action="delete"><i class="fa fa-trash"></i></button>
                    </td>

                  </tr>
                  @empty
                  @endforelse
                  </tbody>
                </table>
                </div>
                
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

<!-- Add Modal -->

<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Ad</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="{{route('ads.store')}}" method="post" class="add-form" enctype="multipart/form-data">
        @csrf
        <div class="modal-body">
          
          <div class="form-group">
          <div class="form-group">
            <label for="from_time" class="col-form-label">From Time:</label>
            <input type="time" name="from_time" id="from_time" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="to_time" class="col-form-label">To Time:</label>
            <input type="time" name="to_time" id="to_time" class="form-control" required>
          </div>
            <label for="name" class="col-form-label">Name:</label>
            <input type="text" name="name" id="name" class="form-control" minlength="3" maxlength="40" placeholder="Name" required>
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">Link:</label>
            <input type="text" name="link" id="link" class="form-control" placeholder="Link" required>
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">Image:(max 2mb) <img src="{{ asset('images/default-ad.png') }}" id="image2" style="width:40px"></label>
            <input type="file" name="image" id="image" accept="image/*" class="form-control" required>
            <small class="text-muted">Supported formats: jpg, jpeg. Max size: 2MB.</small>
      <script>
      document.addEventListener('DOMContentLoaded', function() {
        var imageInput = document.getElementById('image');
        var imagePreview = document.getElementById('image2');
        if(imageInput && imagePreview) {
          imageInput.addEventListener('change', function(e) {
            if (e.target.files && e.target.files[0]) {
              var reader = new FileReader();
              reader.onload = function(ev) {
                imagePreview.src = ev.target.result;
              }
              reader.readAsDataURL(e.target.files[0]);
            }
          });
        }
      });
      </script>
          </div>
          
          <div class="form-group">
            <label for="status" class="col-form-label">Status:</label>
            <select name="status" class="form-control" id="status" required>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
          
          <input type="hidden" name="id" id="edit-id">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="save-button">Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Are you sure ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p class="text"></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal" id="delete-button">Confirm Delete</button>
      </div>
    </div>
  </div>
</div>


@section('script')


<script>
  $(document).ready(function(){
    var id = '';
    var action = '';
    var token = "{{csrf_token()}}";

    $('#deleteModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      id = button.data('id');
      $('#delete-id').val(id);
      action= button.data('action');
      $('#delete-button').removeClass('btn-success');
      $('#delete-button').removeClass('btn-danger');
      $('.modal-title').text('Are you sure ?');
      if(action == 'delete'){
          $('#delete-button').addClass('btn-danger');
          $('#delete-button').text('Confirm Delete');
          $('.text').text('You are going to permanently delete this item..');
      }else{
          $('#delete-button').addClass('btn-success');
          $('#delete-button').text('Confirm Restore');
          $('.text').text('You are going to restore this item..');
      }
    });

    $(document).on('click','#delete-button',function(){
      var url = "{{route('ads.destroy','')}}";
      $.ajax({
        url : url + '/' + id,
        type: "DELETE",
        data : {'_token':token,'id':id,'action':action},
        success: function(data)
        {
          window.location.reload();
        }
      });
    });

    $('#addModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      var edit_id = button.data('id');
      $('#edit-id').val(edit_id);
      $('#name').val(button.data('name'));
      $('#link').val(button.data('link'));
      $('#status').val(button.data('status'));
      $('#from_time').val(button.data('from_time'));
      $('#to_time').val(button.data('to_time'));
      $('.modal-title').text('Add New Ad');
      var imagePath = button.data('image');
      if(imagePath && imagePath !== '') {
        $('#image2').attr('src', imagePath.startsWith('http') ? imagePath : ('/images/' + imagePath));
      } else {
        $('#image2').attr('src', '/images/default-ad.png');
      }
      $('#image').attr('required',true);
      if(edit_id){
          $('.modal-title').text('Update Ad');
          $('#image').attr('required',false);
      }
    });
    // Frontend time validation
    $('.add-form').on('submit', function(e) {
      var fromTime = $('#from_time').val();
      var toTime = $('#to_time').val();
      if (fromTime && toTime && fromTime >= toTime) {
        alert('From Time must be before To Time.');
        e.preventDefault();
        return false;
      }
    });
    
    $('.status').bootstrapSwitch('state');
        $('.status').on('switchChange.bootstrapSwitch',function () {
            var id = $(this).data('id');
            $.ajax({
                url : "{{url('update-ads-status')}}",
                type: "post",
                data : {'_token':token,'id':id,},
                success: function(data)
                {
                  //
                }
            });
        });

  });
</script>
@endsection

@endsection
