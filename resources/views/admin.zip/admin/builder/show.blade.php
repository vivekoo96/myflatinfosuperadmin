@extends('layouts.admin')

@section('title')
    Builder Details
@endsection

@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-md-12">
                @if(session()->has('error'))
                <div class="alert alert-danger">
                    {{ session()->get('error') }}
                </div>
                @endif
                @if(session()->has('success'))
                <div class="alert alert-success">
                    {{ session()->get('success') }}
                </div>
                @endif
            </div>
          <div class="col-sm-6">
            <h1>Builder Details</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Builder Details</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                </div>
                <h3 class="profile-username text-center">{{$builder->name}}</h3>

                <p class="text-muted text-center">{{$builder->company_name}}</p>

                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b>Email</b> <a class="">{{$builder->email}}</a>
                  </li>
                  <li class="list-group-item">
                    <b>Phone</b> <a class="">{{$builder->phone}}</a>
                  </li>
                </ul>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

          </div>
          <!-- /.col -->
          <div class="col-md-12">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item"><a class="nav-link active" href="#buildings" data-toggle="tab">Buildings</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content"> 
                  <div class="tab-pane active" id="buildings">
                    <div class="row">
                        <div class="col-md-12">
                            <button class="btn btn-sm btn-success float-right" data-toggle="modal" data-target="#addModal">Add New Building</button>
                        </div>
                        <div class="table-responsive">
                            <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="white-space: nowrap; text-align: center; width: 60px;">S No</th>
                                    <th>Building Name</th>
                                    <th>BA Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Address</th>
                                    <th>Status</th>
                                    <th style="white-space: nowrap; text-align: center; min-width: 200px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 0; ?>
                                @forelse($builder->buildings as $building)
                                <?php $i++; ?>
                                <tr>
                                    <td>{{$i}}</td>
                                    <td>{{$building->name}}</td>
                                    <td>{{$building->user->name}}</td>
                                    <td>{{$building->user ? $building->user->email : 'N/A'}}</td>
                                    <td>{{$building->phone}}</td>
                                    <td>{{$building->address}}</td>
                                    <td>
                                        {{$building->status}}
                                    </td>
                                    <td style="text-align: center; white-space: nowrap;">
                                    <div class="btn-group" role="group" style="display: inline-flex; gap: 2px;">
                                        <!-- <a href="{{route('buildings.show',$building->id)}}" class="btn btn-sm btn-warning"><i class="fa fa-eye"></i></a> -->
                                        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#addModal" data-id="{{$building->id}}" data-name="{{$building->name}}" data-first_name="{{$building->user->first_name}}" data-last_name="{{$building->user->last_name}}"
                                        data-phone="{{$building->phone}}" data-email="{{$building->user->email}}" data-city="{{$building->city_id}}" data-address="{{$building->address}}" data-status="{{$building->status}}"><i class="fa fa-edit"></i></button>
                                        
                                        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#settingModal" data-id="{{$building->id}}" data-no_of_flats="{{$building->no_of_flats}}" data-no_of_logins="{{$building->no_of_logins}}"
                                        data-no_of_other_users="{{$building->no_of_other_users}}" data-valid_till="{{$building->valid_till}}" data-licence_key="{{$building->licence_key}}" data-permissions="{{ json_encode($building->permissions->pluck('id')) }}"><i class="fa fa-cog"></i></button>
                                        
                                        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#accountModal" data-id="{{$building->id}}" data-payment_is_active="{{$building->payment_is_active}}" data-maintenance_is_active="{{$building->maintenance_is_active}}"
                                        data-corpus_is_active="{{$building->corpus_is_active}}" data-donation_is_active="{{$building->donation_is_active}}" data-facility_is_active="{{$building->facility_is_active}}" data-other_is_active="{{$building->other_is_active}}">
                                        <i class="fa fa-credit-card-alt"></i></button>

                                        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#classifiedModal" data-id="{{$building->id}}" data-within_for_month="{{$building->within_for_month}}" 
                                         data-classified_limit_within_building="{{$building->classified_limit_within_building}}" data-classified_limit_all_building="{{$building->classified_limit_all_building}}" data-all_for_month="{{$building->all_for_month}}">
                                        <i class="fa fa-bath"></i></button>
                                        
                                        @if($building->deleted_at)
                                        <button class="btn btn-sm btn-success" data-toggle="modal" data-target="#deleteModal" data-id="{{$building->id}}" data-action="restore"><i class="fa fa-undo"></i></button>
                                        @else
                                        <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal" data-id="{{$building->id}}" data-action="delete"><i class="fa fa-trash"></i></button>
                                        @endif
                                    </div>
                                    </td>

                                </tr>
                                @empty
                                @endforelse
                            </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                  
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    
<!-- Add Modal -->

<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Building</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="{{route('buildings.store')}}" method="post" class="add-form" enctype="multipart/form-data">
        @csrf
        <div class="modal-body">
          <div class="error"></div>
          <div class="form-group">
            <label for="name" class="col-form-label">Building Name:</label>
            <input type="text" name="name" id="name" class="form-control" placeholder="Building Name" minlength="4" maxlength="60" required>
          </div>
          <div class="form-group">
            <label for="city" class="col-form-label">City:</label>
            <select name="city" id="city" class="form-control" required>
                <option value="">--Select City--</option>
                @forelse($cities as $city)
                <option value="{{$city->id}}">{{$city->name}}</option>
                @empty
                @endforelse
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">Address:</label>
            <textarea name="address" id="address" class="form-control"></textarea>
          </div>

          <div class="form-group">
            <label for="name" class="col-form-label">Building Admin Name:</label>
            <div class="row">
                <div class="col-md-6">
                    <label for="first_name" class="col-form-label">First name</label>
                    <input type="text" name="first_name" id="first_name" class="form-control" placeholder="First Name" minlength="3" maxlength="40" pattern="[A-Za-z\s]+" onkeypress="return event.charCode >= 65 && event.charCode <= 90 || event.charCode >= 97 && event.charCode <= 122 || event.charCode == 32" required>
                </div>
                <div class="col-md-6">
                    <label for="last_name" class="col-form-label">Last name</label>
                    <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Last Name" minlength="3" maxlength="40" pattern="[A-Za-z\s]+" onkeypress="return event.charCode >= 65 && event.charCode <= 90 || event.charCode >= 97 && event.charCode <= 122 || event.charCode == 32" required>
                </div>
            </div>
            
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">Email:</label>
            <input type="email" name="email" id="email" class="form-control" placeholder="Email" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$" required>
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">Phone:</label>
            <input type="text" name="phone" id="phone" class="form-control" placeholder="Phone" minlength="10" maxlength="10" onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">Password:</label>
            <div class="input-group">
              <input type="password" name="password" class="form-control password" minlength="8" maxlength="14" id="password" required>
              <div class="input-group-append">
                <div class="input-group-text">
                  <span class="show-password password-icon"><i class="fa fa-eye-slash"></i></span>
                  <span class="hide-password password-icon" style="display:none;"><i class="fa fa-eye"></i></span>
                </div>
              </div>
              <p clss="mt-1" style="color:grey;font-size:11px;">Enter a combination of at least eight numbers, letters and punctuation marks (such as ! and &)</p>
            </div>
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">Status:</label>
            <select name="status" id="status" class="form-control" required>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
            </select>
          </div>
          <input type="hidden" name="id" id="edit-id">
          <input type="hidden" name="builder_id" value="{{$builder->id}}">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="save-button">Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="settingModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Licence Configuration</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="{{url('building-configration')}}" method="post" class="add-form" enctype="multipart/form-data">
        @csrf
        <div class="modal-body">
          <div class="error"></div>
          <div class="form-group">
            <label for="name" class="col-form-label">Licence Key:</label>
            <textarea name="licence_key" id="licence_key" class="form-control" placeholder="Licence Key" disabled></textarea>
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">No of flats:</label>
            <input type="number" name="no_of_flats" id="no_of_flats" class="form-control" min="0" step="1" pattern="[0-9]+" placeholder="Enter number of flats (minimum 0)" onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
            <small class="form-text text-muted">Enter number of flats</small>
          </div>

          <div class="form-group">
            <label for="name" class="col-form-label">No of Users:</label>
            <input type="number" name="no_of_logins" id="no_of_logins" class="form-control" min="0" step="1" pattern="[0-9]+" placeholder="Enter number of users (minimum 0)" onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
            <small class="form-text text-muted">Enter number of users</small>
          </div>
          
          <div class="form-group">
            <label for="name" class="col-form-label">No of Other Users:</label>
            <input type="number" name="no_of_other_users" id="no_of_other_users" class="form-control" min="0" step="1" pattern="[0-9]+" placeholder="Enter number of other users (minimum 0)" onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
            <small class="form-text text-muted">Enter number of other users</small>
          </div>

          <div class="form-group">
            <label for="name" class="col-form-label">Valid till:</label>
            <input type="date" name="valid_till" id="valid_till" class="form-control" min="{{ \Carbon\Carbon::now()->toDateString() }}" placeholder="Valid Till" required>
          </div>

          <div class="form-group col-md-12">
              <label class="col-form-label">Feature Permissions:</label>
            
              {{-- Master Select All --}}
              <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" id="permission-all">
                <label class="form-check-label font-weight-bold" for="permission-all">Select All</label>
              </div>
            
              {{-- Grouped Permissions --}}
              @foreach($permissions as $group => $items)
                <div class="permission-group border p-2 mb-2">
                  {{-- Group Checkbox --}}
                  <div class="form-check">
                    <input class="form-check-input permission-group-checkbox" type="checkbox" id="group-{{ \Illuminate\Support\Str::slug($group) }}">
                    <label class="form-check-label font-weight-bold text-primary" for="group-{{ \Illuminate\Support\Str::slug($group) }}">{{ $group }}</label>
                  </div>
            
                  {{-- Permissions inside group --}}
                  <div class="ml-3 mt-2">
                    @foreach($items as $permission)
                      <div class="form-check">
                        <input class="form-check-input permission-checkbox permission-group-{{ \Illuminate\Support\Str::slug($group) }}" 
                               type="checkbox" 
                               name="permissions[]" 
                               value="{{ $permission->id }}" 
                               id="permission-{{ $permission->id }}">
                        <label class="form-check-label" for="permission-{{ $permission->id }}">{{ $permission->name }}</label>
                      </div>
                    @endforeach
                  </div>
                </div>
              @endforeach
            </div>

          
          <input type="hidden" name="id" id="edit-id-2">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="settings-save-button" disabled>Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="accountModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Payment Options</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="{{url('building-payment-options')}}" method="post" class="add-form" enctype="multipart/form-data">
        @csrf
        <div class="modal-body">
          <div class="error"></div>

          <div class="form-group">
            <label for="name" class="col-form-label">Own Razorpay Acces:</label>
            <select name="payment_is_active" id="payment_is_active" class="form-control" required>
              <option value="Yes">Own Payment Keys</option>
              <option value="No">Myflatinfo Payment Keys</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">Maintenance Payment:</label>
            <select name="maintenance_is_active" id="maintenance_is_active" class="form-control" required>
              <option value="Yes">Yes</option>
              <option value="No">No</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">Corpus Payment:</label>
            <select name="corpus_is_active" id="corpus_is_active" class="form-control" required>
              <option value="Yes">Yes</option>
              <option value="No">No</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">Donation Payment:</label>
            <select name="donation_is_active" id="donation_is_active" class="form-control" required>
              <option value="Yes">Yes</option>
              <option value="No">No</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">Facility Payment:</label>
            <select name="facility_is_active" id="facility_is_active" class="form-control" required>
              <option value="Yes">Yes</option>
              <option value="No">No</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="col-form-label">Essentials Payment:</label>
            <select name="other_is_active" id="other_is_active" class="form-control" required>
              <option value="Yes">Yes</option>
              <option value="No">No</option>
            </select>
          </div>

          <input type="hidden" name="id" id="edit-id-3">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="save-button">Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="classifiedModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Classified Limit</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="{{url('building-classified-limit')}}" method="post" class="add-form" enctype="multipart/form-data">
        @csrf
        <div class="modal-body">
          <div class="error"></div>

          <div class="form-group row">
            <div class="col-md-6">
                <label for="name" class="col-form-label">Within Building:</label>
                <input type="number" name="classified_limit_within_building" id="classified_limit_within_building" class="form-control" min="0" max="10000" step="1" pattern="[0-9]+" placeholder="Enter limit (0-10000)" onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
                <small class="form-text text-muted">Maximum limit: 10000</small>
            </div>
            <div class="col-md-6">
                <label for="name" class="col-form-label">For Month:</label>
                <input type="number" name="within_for_month" id="within_for_month" class="form-control" min="0" step="1" pattern="[0-9]+" placeholder="Enter months (minimum 0)" onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
                <small class="form-text text-muted">Enter number of months</small>
            </div>
          </div>
          <div class="form-group row">
            <div class="col-md-6">
                <label for="name" class="col-form-label">All Building:</label>
                <input type="number" name="classified_limit_all_building" id="classified_limit_all_building" class="form-control" min="0" max="10000" step="1" pattern="[0-9]+" placeholder="Enter limit (0-10000)" onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
                <small class="form-text text-muted">Maximum limit: 10000</small>
            </div>
            <div class="col-md-6">
                <label for="name" class="col-form-label">For Month:</label>
                <input type="number" name="all_for_month" id="all_for_month" class="form-control" min="0" step="1" pattern="[0-9]+" placeholder="Enter months (minimum 0)" onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
                <small class="form-text text-muted">Enter number of months</small>
            </div>
          </div>
          <input type="hidden" name="id" id="edit-id-4">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="save-button">Save</button>
        </div>
      </form>
    </div>
  </div>
</div>


<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Are you sure ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p class="text"></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal" id="delete-button">Confirm Delete</button>
      </div>
    </div>
  </div>
</div>


@section('script')

<script>
  $(document).ready(function(){
    var id = '';
    var action = '';
    var token = "{{csrf_token()}}";
    
    $('#deleteModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      id = button.data('id');
      $('.modal-title').text('Are you sure ?')
      $('#delete-id').val(id);
      action= button.data('action');
      $('#delete-button').removeClass('btn-success');
      $('#delete-button').removeClass('btn-danger');
      if(action == 'delete'){
          $('#delete-button').addClass('btn-danger');
          $('#delete-button').text('Confirm Delete');
          $('.text').text('You are going to permanently delete this item..');
      }else{
          $('#delete-button').addClass('btn-success');
          $('#delete-button').text('Confirm Restore');
          $('.text').text('You are going to restore this item..');
      }
    });

    $(document).on('click','#delete-button',function(){
      var url = "{{route('buildings.destroy','')}}";
      $.ajax({
        url : url + '/' + id,
        type: "DELETE",
        data : {'_token':token,'action':action},
        success: function(data)
        {
          window.location.reload();
        }
      });
    });

    $('#addModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      var edit_id = button.data('id');
      $('#edit-id').val(edit_id);
      $('#name').val(button.data('name'));
      $('#city').val(button.data('city'));
      $('#address').val(button.data('address'));
      $('#first_name').val(button.data('first_name'));
      $('#last_name').val(button.data('last_name'));
      $('#phone').val(button.data('phone'));
      $('#email').val(button.data('email'));
      $('#status').val(button.data('status'));
      $('.modal-title').text('Add New Building');
      $('#password').attr('required',true);
      if(edit_id){
          $('.modal-title').text('Update Building');
          $('#password').attr('required',false);
      }
      
    });
    
    $('.status').bootstrapSwitch('state');
        $('.status').on('switchChange.bootstrapSwitch',function () {
            var id = $(this).data('id');
            $.ajax({
                url : "{{url('update-user-status')}}",
                type: "post",
                data : {'_token':token,'id':id,},
                success: function(data)
                {
                  //
                }
            });
        });

    $('#settingModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      var edit_id2 = button.data('id');
      $('#edit-id-2').val(edit_id2);
      $('#no_of_flats').val(button.data('no_of_flats'));
      $('#no_of_logins').val(button.data('no_of_logins'));
      $('#no_of_other_users').val(button.data('no_of_other_users'));
      $('#valid_till').val(button.data('valid_till'));
      $('#licence_key').val(button.data('licence_key'));
      $('.modal-title').text('Licence Configuration');
      // Uncheck all facilities first
      $('input[name="permissions[]"]').prop('checked', false);

      // Get assigned facility IDs and check those checkboxes
      var permissions = button.data('permissions'); // already parsed as array by jQuery
      if (Array.isArray(permissions)) {
          permissions.forEach(function(permissionId) {
              $('#permission-' + permissionId).prop('checked', true);
          });
      }
      
    });

    $('#accountModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      var edit_id3 = button.data('id');
      $('#edit-id-3').val(edit_id3);
      $('#payment_is_active').val(button.data('payment_is_active'));
      $('#maintenance_is_active').val(button.data('maintenance_is_active'));
      $('#corpus_is_active').val(button.data('corpus_is_active'));
      $('#donation_is_active').val(button.data('donation_is_active'));
      $('#facility_is_active').val(button.data('facility_is_active'));
      $('#other_is_active').val(button.data('other_is_active'));
      $('.modal-title').text('Payment Options');
      
    });

    $('#classifiedModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget);
      var edit_id4 = button.data('id');
      $('#edit-id-4').val(edit_id4);
      $('#classified_limit_within_building').val(button.data('classified_limit_within_building'));
      $('#classified_limit_all_building').val(button.data('classified_limit_all_building'));
      $('#within_for_month').val(button.data('within_for_month'));
      $('#all_for_month').val(button.data('all_for_month'));
      $('.modal-title').text('Classified Limit');
      
    });

    $('.hide-password').hide();
            
    $(document).on('click','.show-password',function(){
      $('.password').attr('type','text');
      $('.show-password').hide();
      $('.hide-password').show();
    });
    $(document).on('click','.hide-password',function(){
      $('.password').attr('type','password');
      $('.hide-password').hide();
      $('.show-password').show();
    });
    
    // Master "Select All" toggle
    $('#permission-all').change(function () {
      const isChecked = $(this).is(':checked');
      $('input.permission-checkbox, .permission-group-checkbox').prop('checked', isChecked);
      updateSaveButtonState();
    });

    // Group toggle
    $('.permission-group-checkbox').change(function () {
      const groupSlug = this.id.replace('group-', '');
      $('.permission-group-' + groupSlug).prop('checked', $(this).is(':checked'));
      updateSaveButtonState();
    });

    // When any individual checkbox changes, update group and master state
    $('input.permission-checkbox').change(function () {
      // Update group checkbox
      $('.permission-group-checkbox').each(function () {
        const groupSlug = this.id.replace('group-', '');
        const allInGroup = $('.permission-group-' + groupSlug).length;
        const checkedInGroup = $('.permission-group-' + groupSlug + ':checked').length;
        $(this).prop('checked', allInGroup === checkedInGroup);
      });

      // Update master checkbox
      const totalPermissions = $('input.permission-checkbox').length;
      const totalChecked = $('input.permission-checkbox:checked').length;
      $('#permission-all').prop('checked', totalPermissions === totalChecked);
      
      // Enable/disable Save button based on selection
      updateSaveButtonState();
    });

    // Function to update Save button state
    function updateSaveButtonState() {
      const checkedPermissions = $('input.permission-checkbox:checked').length;
      $('#settings-save-button').prop('disabled', checkedPermissions === 0);
    }


    // Update Save button state when modal opens
    $('#settingModal').on('shown.bs.modal', function () {
      updateSaveButtonState();
    });

    // Prevent + and - symbols in classified and license configuration number fields
    $('#classified_limit_within_building, #within_for_month, #classified_limit_all_building, #all_for_month, #no_of_flats, #no_of_logins, #no_of_other_users').on('keypress', function(e) {
      // Allow: backspace, delete, tab, escape, enter
      if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
          // Allow: Ctrl+A, Ctrl+C, Ctrl+V, Ctrl+X
          (e.keyCode === 65 && e.ctrlKey === true) ||
          (e.keyCode === 67 && e.ctrlKey === true) ||
          (e.keyCode === 86 && e.ctrlKey === true) ||
          (e.keyCode === 88 && e.ctrlKey === true)) {
        return;
      }
      // Ensure that it is a number and stop the keypress
      if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
        e.preventDefault();
      }
    });

    // Prevent pasting non-numeric content
    $('#classified_limit_within_building, #within_for_month, #classified_limit_all_building, #all_for_month, #no_of_flats, #no_of_logins, #no_of_other_users').on('paste', function(e) {
      var pastedData = e.originalEvent.clipboardData.getData('text');
      if (!/^\d+$/.test(pastedData)) {
        e.preventDefault();
      }
    });

    // Add form validation for classified modal
    $('#classifiedModal form').on('submit', function(e) {
      var isValid = true;
      var errorMessage = '';

      // Validate Within Building limit
      var withinBuilding = parseInt($('#classified_limit_within_building').val());
      if (isNaN(withinBuilding) || withinBuilding < 0 || withinBuilding > 10000) {
        isValid = false;
        errorMessage += 'Within Building limit must be between 0 and 10000.<br>';
      }

      // Validate Within Building months
      var withinMonth = parseInt($('#within_for_month').val());
      if (isNaN(withinMonth) || withinMonth < 0) {
        isValid = false;
        errorMessage += 'Within Building months must be 0 or greater.<br>';
      }

      // Validate All Building limit
      var allBuilding = parseInt($('#classified_limit_all_building').val());
      if (isNaN(allBuilding) || allBuilding < 0 || allBuilding > 10000) {
        isValid = false;
        errorMessage += 'All Building limit must be between 0 and 10000.<br>';
      }

      // Validate All Building months
      var allMonth = parseInt($('#all_for_month').val());
      if (isNaN(allMonth) || allMonth < 0) {
        isValid = false;
        errorMessage += 'All Building months must be 0 or greater.<br>';
      }

      if (!isValid) {
        e.preventDefault();
        $('#classifiedModal .error').html('<div class="alert alert-danger">' + errorMessage + '</div>');
        return false;
      } else {
        $('#classifiedModal .error').html('');
      }
    });

    // Add form validation for settings modal (License configuration)
    $('#settingModal form').on('submit', function(e) {
      var isValid = true;
      var errorMessage = '';

      // Validate No of flats
      var noOfFlats = parseInt($('#no_of_flats').val());
      if (isNaN(noOfFlats) || noOfFlats < 0) {
        isValid = false;
        errorMessage += 'Number of flats must be 0 or greater.<br>';
      }

      // Validate No of users
      var noOfUsers = parseInt($('#no_of_logins').val());
      if (isNaN(noOfUsers) || noOfUsers < 0) {
        isValid = false;
        errorMessage += 'Number of users must be 0 or greater.<br>';
      }

      // Validate No of other users
      var noOfOtherUsers = parseInt($('#no_of_other_users').val());
      if (isNaN(noOfOtherUsers) || noOfOtherUsers < 0) {
        isValid = false;
        errorMessage += 'Number of other users must be 0 or greater.<br>';
      }

      // Check if at least one permission is selected
      var checkedPermissions = $('input.permission-checkbox:checked').length;
      if (checkedPermissions === 0) {
        isValid = false;
        errorMessage += 'Please select at least one Feature Permission.<br>';
      }

      if (!isValid) {
        e.preventDefault();
        $('#settingModal .error').html('<div class="alert alert-danger">' + errorMessage + '</div>');
        return false;
      } else {
        $('#settingModal .error').html('');
      }
    });

    // Add form validation for add building modal
    $('#addModal form').on('submit', function(e) {
      var isValid = true;
      var errorMessage = '';

      // Validate First Name (alphabets only)
      var firstName = $('#first_name').val().trim();
      if (!/^[A-Za-z\s]+$/.test(firstName)) {
        isValid = false;
        errorMessage += 'First name should contain only alphabets and spaces.<br>';
      }

      // Validate Last Name (alphabets only)
      var lastName = $('#last_name').val().trim();
      if (!/^[A-Za-z\s]+$/.test(lastName)) {
        isValid = false;
        errorMessage += 'Last name should contain only alphabets and spaces.<br>';
      }

      // Validate Email (single TLD)
      var email = $('#email').val().trim();
      var emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
      if (!emailPattern.test(email)) {
        isValid = false;
        errorMessage += 'Please enter a valid email address with single TLD.<br>';
      }

      // Validate Phone (10 digits only)
      var phone = $('#phone').val().trim();
      if (!/^\d{10}$/.test(phone)) {
        isValid = false;
        errorMessage += 'Phone number must be exactly 10 digits.<br>';
      }

      if (!isValid) {
        e.preventDefault();
        $('#addModal .error').html('<div class="alert alert-danger">' + errorMessage + '</div>');
        return false;
      } else {
        $('#addModal .error').html('');
      }
    });

  });
</script>
@endsection

@endsection
