@extends('layouts.admin')

@section('title')
    Dashboard
@endsection

@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Dashboards</h1>
          </div>
          <div class="col-sm-6">
          <button class="btn btn-sm btn-success right" data-toggle="modal" data-target="#deleteModal">Clear Database</button>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                @php
                    $user = Auth::user();
                    $userPermissions = $user->permissions->pluck('slug')->toArray();
                    $isSuperAdmin = $user->role === 'super-admin';
                @endphp
                @if($isSuperAdmin || in_array('view_admins', $userPermissions))
                <div class="col-lg-3 col-6">
                    <a href="{{url('/admins')}}">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{\App\Models\User::where('role','admin')->where('status','Active')->count()}}</h3>
                            <p>Total Admins</p>
                        </div>
                    </div>
                    </a>
                </div>
                @endif
                @if($isSuperAdmin || in_array('view_building_admins', $userPermissions))
                <div class="col-lg-3 col-6">
                    <a href="{{url('/building-admins')}}">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{\App\Models\User::where('role','BA')->count()}}</h3>
                            <p>Total BA</p>
                        </div>
                    </div>
                    </a>
                </div>
                @endif
                @if($isSuperAdmin || in_array('view_builders', $userPermissions))
                <div class="col-lg-3 col-6">
                    <a href="{{route('builder.index')}}">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{\App\Models\Builder::count()}}</h3>
                            <p>Builders</p>
                        </div>
                    </div>
                    </a>
                </div>
                @endif
                @if($isSuperAdmin || in_array('view_buildings', $userPermissions))
                <div class="col-lg-3 col-6">
                    <a href="{{url('buildings')}}">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{\App\Models\Building::count()}}</h3>
                            <p>Buildings</p>
                        </div>
                    </div>
                    </a>
                </div>
                @endif
                @if($isSuperAdmin || in_array('view_cities', $userPermissions))
                <div class="col-lg-3 col-6">
                    <a href="{{route('city.index')}}">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{\App\Models\City::count()}}</h3>
                            <p>City</p>
                        </div>
                    </div>
                    </a>
                </div>
                @endif
                @if($isSuperAdmin || in_array('view_ads', $userPermissions))
                <div class="col-lg-3 col-6">
                    <a href="{{route('ads.index')}}">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{\App\Models\Ad::count()}}</h3>
                            <p>Ads</p>
                        </div>
                    </div>
                    </a>
                </div>
                @endif
                @if(!$isSuperAdmin && empty($userPermissions))
                <div class="col-12">
                    <div class="alert alert-warning mt-4">You do not have any permissions assigned. Please contact the super admin.</div>
                </div>
                @endif
            </div>
        </div>
    </section>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Are you sure ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p class="text">You are going truncate all the databases</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal" id="delete-button">Confirm Delete</button>
      </div>
    </div>
  </div>
</div>

@section('script')

<script>
    
    $(document).ready(function(){
        var id = '';
        var token = "{{csrf_token()}}";

        $(document).on('click','#delete-button',function(){
            var url = "{{url('clear-database')}}";
            $.ajax({
                url : url,
                type: "POST",
                data : {'_token':token},
                success: function(data)
                {
                    window.location.reload();
                }
            });
        });
    });
</script>
@endsection

@endsection