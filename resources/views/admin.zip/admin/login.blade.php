<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="Ml63mUEFyaGvIM0h52l8aZ6cEGkZ61t2Jw0t9jhv" />
    <title>Admin Panel | {{$setting->business_name}}</title>
    <link rel="stylesheet" type="text/css" href="{{asset('admin/css/bootstrap.min.css')}}">
    <link rel="shortcut icon" href="{{$setting->favicon}}">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        * {
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background-color: black;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow-x: hidden;
        }
        
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="white" opacity="0.1"/><circle cx="75" cy="75" r="1" fill="white" opacity="0.1"/><circle cx="50" cy="10" r="0.5" fill="white" opacity="0.15"/><circle cx="10" cy="50" r="0.5" fill="white" opacity="0.15"/><circle cx="90" cy="30" r="0.5" fill="white" opacity="0.15"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            pointer-events: none;
            animation: backgroundPulse 4s ease-in-out infinite;
        }
        
        /* Floating particles illusion */
        body::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: radial-gradient(circle at 20% 80%, rgba(255, 255, 255, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, rgba(255, 255, 255, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 40% 40%, rgba(255, 255, 255, 0.05) 0%, transparent 50%);
            pointer-events: none;
            animation: floatingParticles 6s ease-in-out infinite;
        }
        
        .login-container {
            width: 100%;
            max-width: 450px;
            padding: 20px;
            position: relative;
            z-index: 1;
        }
        
        .login-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1), 0 0 0 1px rgba(255, 255, 255, 0.2);
            border: none;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            animation: cardFloat 3s ease-in-out infinite, cardGlow 2s ease-in-out infinite alternate;
        }
        
        .login-card:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 30px 60px rgba(0, 0, 0, 0.15), 0 0 0 1px rgba(255, 255, 255, 0.3);
        }
        
        .card-header {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
            border: none;
            padding: 40px 30px 30px;
            text-align: center;
            position: relative;
        }
        
        .card-header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 3px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 2px;
        }
        
        .logo-container {
            margin-bottom: 20px;
        }
        
        .logo-container img {
            max-width: 180px;
            height: auto;
            filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
        }
        
        .card-body {
            padding: 40px 40px 50px;
            background: white;
        }
        
        .login-title {
            font-size: 28px;
            font-weight: 600;
            color: #2d3748;
            margin-bottom: 10px;
            text-align: center;
        }
        
        .login-subtitle {
            color: #718096;
            text-align: center;
            margin-bottom: 30px;
            font-size: 16px;
        }
        
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #4a5568;
            font-size: 14px;
        }
        
        .form-control {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: #f7fafc;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            transform: translateY(-1px);
        }
        
        .input-group {
            position: relative;
        }
        
        .input-group-append {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            z-index: 10;
        }
        
        .password-icon {
            cursor: pointer;
            color: #a0aec0;
            transition: color 0.3s ease;
            padding: 5px;
        }
        
        .password-icon:hover {
            color: #667eea;
        }
        
        .btn-login {
            width: 100%;
            padding: 16px;
            background-color: black;
            border: none;
            border-radius: 12px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .btn-login::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
        }
        
        .btn-login:hover::before {
            left: 100%;
        }
        
        .btn-login:active {
            transform: translateY(0);
        }
        
        .links-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 25px;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .auth-link {
            color: #dc3545;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .auth-link::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: #dc3545;
            transition: width 0.3s ease;
        }
        
        .auth-link:hover {
            color: #c82333;
            text-decoration: none;
        }
        
        .auth-link:hover::after {
            width: 100%;
        }
        
        .footer-text {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
            color: #718096;
            font-size: 13px;
        }
        
        .footer-text a {
            color: black;
            text-decoration: none;
            font-weight: 500;
        }
        
        .alert {
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            border: none;
            font-size: 14px;
        }
        
        .alert-danger {
            background: linear-gradient(135deg, #fed7d7, #feb2b2);
            color: #c53030;
        }
        
        .alert-success {
            background: linear-gradient(135deg, #c6f6d5, #9ae6b4);
            color: #2f855a;
        }
        
        @media (max-width: 768px) {
            .login-container {
                padding: 15px;
            }
            
            .card-body {
                padding: 30px 25px 40px;
            }
            
            .card-header {
                padding: 30px 25px 25px;
            }
            
            .login-title {
                font-size: 24px;
            }
            
            .links-container {
                flex-direction: column;
                text-align: center;
            }
        }
        
        @media (max-width: 480px) {
            .form-control {
                padding: 12px 15px;
                font-size: 16px;
            }
            
            .btn-login {
                padding: 14px;
                font-size: 15px;
            }
        }
        
        /* Loading animation */
        .loading {
            position: relative;
            pointer-events: none;
        }
        
        .loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 20px;
            height: 20px;
            margin: -10px 0 0 -10px;
            border: 2px solid transparent;
            border-top: 2px solid white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Visual illusion animations */
        @keyframes backgroundPulse {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 0.6; }
        }
        
        @keyframes floatingParticles {
            0%, 100% { 
                transform: translateY(0px) rotate(0deg);
                opacity: 0.3;
            }
            33% { 
                transform: translateY(-10px) rotate(120deg);
                opacity: 0.6;
            }
            66% { 
                transform: translateY(5px) rotate(240deg);
                opacity: 0.4;
            }
        }
        
        @keyframes cardFloat {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-3px); }
        }
        
        @keyframes cardGlow {
            0% { 
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1), 0 0 0 1px rgba(255, 255, 255, 0.2);
            }
            100% { 
                box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15), 0 0 20px rgba(255, 255, 255, 0.3);
            }
        }
    </style>


</head>

<body>
    <div class="login-container">
        <div class="login-card">
            <div class="card-header">
                <div class="logo-container">
                    <img src="{{$setting->logo}}" alt="{{$setting->business_name}} Logo">
                </div>
            </div>
            <div class="card-body">
                <h1 class="login-title">Super Admin Login</h1>
                <p class="login-subtitle">Welcome back! Please sign in to your account.</p>
                        <form action="{{url('login')}}" method="post">
                            @csrf
                            @if(session()->has('error'))
                                <div class="alert alert-danger">
                                    {{ session()->get('error') }}
                                </div>
                            @endif
                            @if(session()->has('success'))
                                <div class="alert alert-success">
                                    {{ session()->get('success') }}
                                </div>
                            @endif

                            <div class="form-group">
                                <label class="form-label">Email Address</label>
                                <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Password</label>
                                <div class="input-group">
                                    <input type="password" name="password" class="form-control password" placeholder="Enter your password" minlength="8" maxlength="14" id="re_pass" required>
                                    <div class="input-group-append">
                                        <span class="show-password password-icon"><i class="fa fa-eye-slash"></i></span>
                                        <span class="hide-password password-icon" style="display:none;"><i class="fa fa-eye"></i></span>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="device_token" name="device_token" value="">
                            <div class="form-group">
                                <button type="submit" class="btn-login">
                                    Sign In
                                </button>
                            </div>
                            <div class="links-container" style="justify-content: flex-end;">
                                <!-- <a href="/" class="auth-link" target="_blank">Go to User Panel</a> -->
                                <a href="{{url('forget-password')}}" class="auth-link" target="_blank">Forgot Password?</a>
                            </div>
                            
                            <div class="footer-text">
                                <p>© Copyright <a href="/" target="_blank">{{$setting->business_name}}</a></p>
                                <p>Designed by <a href="https://analogueitsolutions.com/" target="_blank">Analogue IT Solutions</a> Pvt Ltd</p>
                            </div>
                        </form>
            </div>
        </div>
    </div>
    <script src="{{asset('admin/plugins/jquery/jquery.min.js')}}"></script>
    <script>
        $(document).ready(function(){
            $('.hide-password').hide();
            
            $(document).on('click','.show-password',function(){
                $('.password').attr('type','text');
                $('.show-password').hide();
                $('.hide-password').show();
            });
            $(document).on('click','.hide-password',function(){
                $('.password').attr('type','password');
                $('.hide-password').hide();
                $('.show-password').show();
            });
        });
        
    </script>
    <script>
        $(document).ready(function(){
            window.history.pushState(null, "", window.location.href);
            window.onpopstate = function () {
                window.history.pushState(null, "", window.location.href);
            };

        });
    </script>
    
</body>

<script type="module">

  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.9.3/firebase-app.js";

  import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.9.3/firebase-analytics.js";

  const firebaseConfig = {

    apiKey: "AIzaSyCMIXqJyXbmxmFMdywPuFbYd6cRUx-l6nc",

    authDomain: "school-979f6.firebaseapp.com",

    databaseURL: "https://school-979f6.firebaseio.com",

    projectId: "school-979f6",

    storageBucket: "school-979f6.appspot.com",

    messagingSenderId: "308636612449",

    appId: "1:308636612449:web:603eb003f33921ad9db720",

    measurementId: "G-45CQ9YMRNN"

  };


  // Initialize Firebase

  const app = initializeApp(firebaseConfig);

  const analytics = getAnalytics(app);
  
  
    import { getMessaging, getToken } from "https://www.gstatic.com/firebasejs/9.9.3/firebase-messaging.js";

    const messaging = getMessaging();
    getToken(messaging, { vapidKey: 'BALAriAKrgC8UL3txmvobWMeu2wRZ4g-7wX4TxOI6-JzE9b5oZWUMwUANBJ2w0V3glmlsBGIV0SNlofoApPf9e0' }).then((currentToken) => {
      if (currentToken) {
        document.getElementById("device_token").value = currentToken;
      } else {
        // Show permission request UI
        console.log('No registration token available. Request permission to generate one.');
        // ...
      }
    }).catch((err) => {
      console.log('An error occurred while retrieving token. ', err);
      // ...
    });
    

</script>

</html>